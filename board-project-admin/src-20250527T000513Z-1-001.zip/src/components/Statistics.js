import React  from "react";

export default function Statistics() {
  return (
    <div>
      <section className="statistics-section">
        <h2>가장 조회수 많은 게시글</h2>
      </section>

      <section className="statistics-section">
        <h2>가장 좋아요 많은 게시글</h2>
      </section>

      <section className="statistics-section">
        <h2>가장 댓글 많은 게시글</h2>
      </section>
    </div>
  );
}
